import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import scipy as sp
import matplotlib.pyplot as plt

def func(x, y):
    return x**2 + 10*np.sin(y)

x = np.linspace(0,10)
X, Y = np.meshgrid(x,x)
Z = func(X, Y)

plt.figure()
for i in range(0, len(x), 10):
    plt.plot(X[i,:], Z[i,:])

fig = plt.figure()
ax = fig.gca(projection='3d')
ax.plot_surface(X, Y, Z)

plt.show()