print 'Hello world'

# add some calculation
a = 6
b = 7
print 'Additional calculation: ', a*b